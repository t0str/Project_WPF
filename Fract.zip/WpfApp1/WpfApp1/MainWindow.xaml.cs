﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        /// <summary>
        /// Рекурсивная функция для дерева Пифагора.
        /// </summary>
        /// <param name="attitude"> Коэффициент уменьшения отрезка. </param>
        /// <param name="left"> Угол на который надо наклонять левую ветку. </param>
        /// <param name="right"> Угол на который надо наклонять правую ветку. </param>
        /// <param name="x"> Координата х начальной точки. </param>
        /// <param name="y"> Координата у начальной точки. </param>
        /// <param name="lenght"> Длина предыдущего отрезка. </param>
        /// <param name="number"> Количество итераций. </param>
        /// <param name="leftC"> Угол на который наклоняется левая ветка. </param>
        /// <param name="rightC"> Угол на который наклоняется правая ветка. </param>
        public void Pif(double attitude,double left, double right,int x,int y,double lenght,int number,double leftC,double rightC)
        {
            if (number != 0)
            {
                number--;
                Line vert1 = new Line();
                vert1.X1 = x;
                vert1.Y1 = y;
                vert1.X2 = (int)(x + Math.Sin(Math.PI-left) * lenght / attitude);
                vert1.Y2 = (int)(y + Math.Cos(Math.PI-left) * lenght / attitude);
                vert1.Stroke = Brushes.Black;
                grid1.Children.Add(vert1);
                Pif(attitude, left+leftC, right-leftC, (int)(x + Math.Sin(Math.PI - left) * lenght / attitude), (int)(y + Math.Cos(Math.PI - left) * lenght / attitude), lenght / attitude, number,leftC,rightC);
                Line vert2 = new Line();
                vert2.X1 = x;
                vert2.Y1 = y;
                vert2.X2 = (int)(x + Math.Sin(Math.PI + right) * lenght / attitude);
                vert2.Y2 = (int)(y + Math.Cos(Math.PI + right) * lenght / attitude);
                vert2.Stroke = Brushes.Black;
                grid1.Children.Add(vert2);
                Pif(attitude, left-rightC, right + rightC, (int)(x + Math.Sin(Math.PI + right) * lenght / attitude), (int)(y + Math.Cos(Math.PI + right) * lenght / attitude), lenght / attitude, number, leftC, rightC);
            }
        }

        /// <summary>
        /// Рекурсивная функция для множества Кантора.
        /// </summary>
        /// <param name="x1"> Первая координата по х. </param>
        /// <param name="x2"> Вторая координата по х. </param>
        /// <param name="number"> Количество итераций. </param>
        /// <param name="y"> Текущее положение по у. </param>
        /// <param name="height"> Расстояние между прямыми соседних итераций. </param>
        public void Kant(int x1, int x2,int number,int y,int height)
        {
            if (number != 0) {
                Line vert1 = new Line();
                --number;
                vert1.X1 = x1;
                vert1.Y1 = y + height;
                vert1.X2 = ((x2-x1) / 3)+x1;
                vert1.Y2 = y + height;
                vert1.Stroke = Brushes.Black;
                grid1.Children.Add(vert1);
                Kant(x1,((x2-x1)/3)+x1,number,y+height,height);
                Line vert2 = new Line();
                vert2.X1 = (2 * (x2-x1) / 3)+x1;
                vert2.Y1 = y + height;
                vert2.X2 = x2;
                vert2.Y2 = y + height;
                vert2.Stroke = Brushes.Black;
                grid1.Children.Add(vert2);
                Kant((2 * (x2-x1) / 3)+x1, x2, number, y + height,height);
            }
        }

        /// <summary>
        /// Рекурсивная функция для кривой Коха.
        /// </summary>
        /// <param name="k"> Коллекция точек, которые содержатся в кривой Коха. </param>
        /// <param name="number"> Количество итераций. </param>
        public void Koha(ref PointCollection k,int number)
        {
            if (number != 0)
            {
                number--;
                double x1,x2,y1,y2;
                int a = k.Count;
                int i = 0;
                for(int j = 0; j < a-1; j++)
                {
                    x1 = (k[i + 1].X - k[i].X) / 3 + k[i].X;
                    y1= ((k[i + 1].Y - k[i].Y) / 3) + k[i].Y;
                    x2 = 2 * (k[i + 1].X - k[i].X) / 3 + k[i].X;
                    y2 = (2 * (k[i + 1].Y - k[i].Y) / 3) + k[i].Y;
                    k.Insert(k.IndexOf(k[i])+1,new Point(x1, y1));
                    k.Insert(k.IndexOf(k[i]) + 2,new Point((x1 - x2)/2 - Math.Sqrt(3)* (y1 - y2)/2 + x2, Math.Sqrt(3) * (x1 - x2) / 2 + (y1 - y2) / 2 + y2));
                    k.Insert(k.IndexOf(k[i]) + 3,new Point(x2, y2));
                    i += 4;
                }
                Koha(ref k, number);
            }
        }

        /// <summary>
        /// Рекурсивная функция для ковра Серпинского.
        /// </summary>
        /// <param name="x1"> Первая координата по х квадрата. </param>
        /// <param name="x2"> Вторая координата по х квадрата. </param>
        /// <param name="y1"> Первая координата по у квадрата. </param>
        /// <param name="y2"> Вторая координата по у квадрата</param>
        /// <param name="number"> Количество итераций. </param>
        public void Carpet(double x1,double x2,double y1,double y2,int number)
        {
            if (number != 0)
            {
                number--;
                Polygon r1 = new();
                r1.Points.Add(new Point((x2 - x1) / 3 + x1, (y2 - y1) / 3 + y1));
                r1.Points.Add(new Point((x2 - x1) / 3 + x1, 2 * (y2 - y1) / 3 + y1));
                r1.Points.Add(new Point(2 * (x2 - x1) / 3 + x1, 2 * (y2 - y1) / 3 + y1));
                r1.Points.Add(new Point(2 * (x2 - x1) / 3 + x1, (y2 - y1) / 3 + y1));
                r1.Fill = Brushes.White;
                grid1.Children.Add(r1);

                Carpet(x1, (x2 - x1) / 3 + x1, y1, (y2 - y1) / 3 + y1, number);
                Carpet(x2, 2 * (x2 - x1) / 3 + x1, y2, 2 * (y2 - y1) / 3 + y1, number);
                Carpet(x1, (x2 - x1) / 3 + x1, y2, 2 * (y2 - y1) / 3 + y1, number);
                Carpet((x2 - x1) / 3 + x1, 2 * (x2 - x1) / 3 + x1, y1, (y2 - y1) / 3 + y1, number);
                Carpet(x1, (x2 - x1) / 3 + x1, (y2 - y1) / 3 + y1, 2 * (y2 - y1) / 3 + y1, number);
                Carpet((x2 - x1) / 3 + x1, 2 * (x2 - x1) / 3 + x1, y2, 2 * (y2 - y1) / 3 + y1, number);
                Carpet(x2, 2 * (x2 - x1) / 3 + x1, y1, (y2 - y1) / 3 + y1, number);
                Carpet(x2, 2 * (x2 - x1) / 3 + x1, (y2 - y1) / 3 + y1, 2 * (y2 - y1) / 3 + y1, number);
            }
        }

        /// <summary>
        /// Рекурсивная функция для треугольника Серпинского.
        /// </summary>
        /// <param name="number"> Количество итераций. </param>
        /// <param name="point1"> Первая точка треугольника. </param>
        /// <param name="point2"> Вторая точка треугольника. </param>
        /// <param name="point3"> Третья точка треугольника. </param>
        public void Triangle(int number, Point point1, Point point2, Point point3)
        {
            number--;
            var polygon = new Polygon();
            polygon.Stroke = Brushes.Black;
            var newPoint1 = new Point((point2.X + point3.X) / 2, (point2.Y + point3.Y) / 2);
            var newPoint2 = new Point((point1.X + point3.X) / 2, (point1.Y + point3.Y) / 2);
            var newPoint3 = new Point((point1.X + point2.X) / 2, (point1.Y + point2.Y) / 2);
            var pointCollection = new PointCollection();
            pointCollection.Add(newPoint1);
            pointCollection.Add(newPoint2);
            pointCollection.Add(newPoint3);
            polygon.Points = pointCollection;
            grid1.Children.Add(polygon);
            if (number >= 0)
            {
                Triangle(number, point1, newPoint2, newPoint3);
                Triangle(number, newPoint1, point2, newPoint3);
                Triangle(number, newPoint1, newPoint2, point3);
            }
        }

        /// <summary>
        /// Точка входа.
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Рисование дерева Пифагора.
        /// </summary>
        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            int number;
            double leftAngle;
            double rightAngle;
            double attitude;
            if (!int.TryParse(textBox.Text, out number) || (number < 1) || (number > 5))
            {
                MessageBox.Show("Некорректные данные глубины рекурсии.");

            }
            else
            {
                if (!double.TryParse(textBox3.Text, out leftAngle) || (leftAngle < 10) || (leftAngle > 80))
                {
                    MessageBox.Show("Некорректные данные угла левого отрезка.");
                }
                else
                {
                    if (!double.TryParse(textBox4.Text, out rightAngle) || (rightAngle < 10) || (rightAngle > 80))
                    {
                        MessageBox.Show("Некорректные данные угла правого отрезка.");
                    }
                    else
                    {
                        if (!double.TryParse(textBox5.Text, out attitude) || (attitude < 1.5) || (attitude > 2))
                        {
                            MessageBox.Show("Некорректные данные отношения отрезков.");
                        }
                        else
                        {
                            grid1.Children.Clear();
                            Line vertU = new Line();
                            vertU.X1 = 200;
                            vertU.Y1 = 200;
                            vertU.X2 = 200;
                            vertU.Y2 = 300;
                            vertU.Stroke = Brushes.Black;
                            grid1.Children.Add(vertU);
                            double left = rightAngle;
                            double right = leftAngle;
                            left = left * Math.PI / 180;
                            right = right * Math.PI / 180;
                            Pif(attitude, left, right, 200, 200, 100, number, left, right);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Рисование кривой Коха.
        /// </summary>
        private void RadioButton2_Checked(object sender, RoutedEventArgs e)
        {
            int number;
            if (!int.TryParse(textBox.Text, out number) || (number < 1) || (number > 5))
            {
                MessageBox.Show("Некорректные данные глубины рекурсии.");

            }
            else
            {
                grid1.Children.Clear();
                Polyline koha = new();
                PointCollection kollectionKoha = new PointCollection();
                kollectionKoha.Add(new Point(0, 200));
                kollectionKoha.Add(new Point(400, 200));
                Koha(ref kollectionKoha, number);
                koha.Points = kollectionKoha;
                koha.Stroke = Brushes.Black;
                grid1.Children.Add(koha);
            }
        }

        /// <summary>
        /// Рисование ковра Серпинского.
        /// </summary>
        private void RadioButton3_Checked(object sender, RoutedEventArgs e)
        {
            int number;
            if (!int.TryParse(textBox.Text, out number) || (number < 1) || (number > 5))
            {
                MessageBox.Show("Некорректные данные глубины рекурсии.");

            }
            else
            {
                grid1.Children.Clear();
                Polygon square = new();
                square.Points.Add(new Point(0, 0));
                square.Points.Add(new Point(0, 300));
                square.Points.Add(new Point(300, 300));
                square.Points.Add(new Point(300, 0));
                square.Fill = Brushes.Blue;
                grid1.Children.Add(square);
                Carpet(0, 300, 0, 300, number);
            }
        }

        /// <summary>
        /// Рисование треугольника Серпинского.
        /// </summary>
        private void RadioButton4_Checked(object sender, RoutedEventArgs e)
        {
            int number;
            if (!int.TryParse(textBox.Text, out number) || (number < 1) || (number > 5))
            {
                MessageBox.Show("Некорректные данные глубины рекурсии.");

            }
            else
            {
                grid1.Children.Clear();
                int numbers = number;
                var polygon = new Polygon();
                polygon.Stroke = Brushes.Black;
                var point1 = new Point(250, 300 - Math.Sqrt(67500));
                var point2 = new Point(400, 300);
                var point3 = new Point(100, 300);
                var pointCollection = new PointCollection();
                pointCollection.Add(point1);
                pointCollection.Add(point2);
                pointCollection.Add(point3);
                polygon.Points = pointCollection.Clone();
                grid1.Children.Add(polygon);
                if (numbers > 0)
                {
                    pointCollection.Clear();
                    var newPoint1 = new Point(250, 300);
                    var newPoint2 = new Point(175, 300 - Math.Sqrt(16875));
                    var newPoint3 = new Point(325, 300 - Math.Sqrt(16875));
                    pointCollection.Add(newPoint1);
                    pointCollection.Add(newPoint2);
                    pointCollection.Add(newPoint3);
                    var polygon1 = new Polygon();
                    polygon1.Stroke = Brushes.Black;
                    polygon1.Points = pointCollection;
                    grid1.Children.Add(polygon1);
                    numbers -= 2;
                    if (numbers >= 0)
                    {
                        Triangle(numbers, point1, newPoint2, newPoint3);
                        Triangle(numbers, newPoint1, point2, newPoint3);
                        Triangle(numbers, newPoint1, newPoint2, point3);
                    }
                }
            }
        }

        /// <summary>
        /// Рисование множества Кантора.
        /// </summary>
        private void RadioButton5_Checked(object sender, RoutedEventArgs e)
        {
            int number;
            int height;
            if (!int.TryParse(textBox.Text, out number) || (number < 1) || (number > 5))
            {
                MessageBox.Show("Некорректные данные глубины рекурсии.");

            }
            else
            {
                if (!int.TryParse(textBox2.Text, out height) || (height < 10) || (height > 20))
                {
                    MessageBox.Show("Некорректные данные расстояния между отрезками разных итераций.");
                }
                else
                {
                    grid1.Children.Clear();
                    Line vertL = new Line();
                    vertL.X1 = 0;
                    vertL.Y1 = 0;
                    vertL.X2 = 400;
                    vertL.Y2 = 0;
                    vertL.Stroke = Brushes.Black;
                    grid1.Children.Add(vertL);
                    Kant(0, 400, number, 0, height);
                }
            }
        }

        private void textBox3_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
